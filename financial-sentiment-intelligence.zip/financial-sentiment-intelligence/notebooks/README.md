# Notebooks

Exploratory notebooks will live here.

The core training and prediction logic stays in `src/` so that the project can be tested and run without depending on notebook state.
